﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace F_I_L
{
    public partial class Form1 : Form
    {
        private Form2 F2;
        private Form1 F1;
        private Form3 F3;
        private Form5 F5;


        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            F5 = new Form5();
            F1 = new Form1();
            F5.Show();
            F1.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            F3 = new Form3();
            F1 = new Form1();
            F3.Show();
            F1.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            F2 = new Form2();
            F1 = new Form1();
            F2.Show();
            F1.Close();
        }
    }
}
