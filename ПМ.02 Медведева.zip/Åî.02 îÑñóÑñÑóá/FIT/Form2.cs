﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace F_I_L
{
    public partial class Form2 : Form
    {


        public Form2()
        {
            InitializeComponent();
        }

        private void деятельность_сети_FILBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.деятельность_сети_FILBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.fITDataSet);

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "fITDataSet.Деятельность_сети_FIL". При необходимости она может быть перемещена или удалена.
            this.деятельность_сети_FILTableAdapter.Fill(this.fITDataSet.Деятельность_сети_FIL);

        }


    }
}
